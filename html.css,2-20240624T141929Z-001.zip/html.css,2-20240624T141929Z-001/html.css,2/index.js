const gifsPerPage = 2;
const div =1;
let currentPage = 1;

const gifs = [
    "https://www.pokemon.com/static-assets/content-assets/cms2/img/pokedex/full/720.png",
    "https://www.pokemon.com/static-assets/content-assets/cms2/img/pokedex/full/720_f2.png",
    "https://w7.pngwing.com/pngs/440/469/png-transparent-pokemon-sun-and-moon-pokemon-ultra-sun-and-ultra-moon-zygarde-pokemon-x-and-y-others-fictional-character-pokemon-pokemon-x-and-y-thumbnail.png",
    "https://pm1.aminoapps.com/6370/5840e4418596ecbf1651f1a4e26a5fd22c0bca8c_hq.jpg",
    "https://www.pokemon.com/static-assets/content-assets/cms2/img/pokedex/full/487.png",
    "https://www.pokemon.com/static-assets/content-assets/cms2/img/pokedex/full/487_f2.png",
    "https://www.pokemon.com/static-assets/content-assets/cms2/img/pokedex/full/484.png",
    "https://4.bp.blogspot.com/-HhwrVjSAUIg/WsuD91LwIHI/AAAAAAAAFvk/AKsaD9X2C2shra-Ry9uH0kTjbJpe25M7ACLcBGAs/s1600/palkia_in_copic_markers_by_chibi_pika-d8cuma0%2B%25281%2529.png",
    "https://www.pokemon.com/static-assets/content-assets/cms2/img/pokedex/full/384.png",
    "https://images-wixmp-ed30a86b8c4ca887773594c2.wixmp.com/f/176721c7-cb37-4a45-a0b8-dccfa82710b8/df7xcgy-ffbd105e-9272-4f92-bad1-0fc7ceac509f.png/v1/fill/w_1280,h_1182/shiny_rayquaza_10_by_goomy341_df7xcgy-fullview.png?token=eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJ1cm46YXBwOjdlMGQxODg5ODIyNjQzNzNhNWYwZDQxNWVhMGQyNmUwIiwiaXNzIjoidXJuOmFwcDo3ZTBkMTg4OTgyMjY0MzczYTVmMGQ0MTVlYTBkMjZlMCIsIm9iaiI6W1t7ImhlaWdodCI6Ijw9MTE4MiIsInBhdGgiOiJcL2ZcLzE3NjcyMWM3LWNiMzctNGE0NS1hMGI4LWRjY2ZhODI3MTBiOFwvZGY3eGNneS1mZmJkMTA1ZS05MjcyLTRmOTItYmFkMS0wZmM3Y2VhYzUwOWYucG5nIiwid2lkdGgiOiI8PTEyODAifV1dLCJhdWQiOlsidXJuOnNlcnZpY2U6aW1hZ2Uub3BlcmF0aW9ucyJdfQ.CiWQ3sSgBM7KphAKDLxLys-y7G2TZ5FJChfw85JuXjE"
];

function showPage(page) {
    const start = (page - 1) * gifsPerPage;
    const end = start + gifsPerPage;
    const gifsToShow = gifs.slice(start, end);

    const gifContainer = document.getElementById('gif-container');
    gifContainer.innerHTML = '';
    gifsToShow.forEach(gif => {
        const img = document.createElement('img');
        img.src = gif;
        gifContainer.appendChild(img);
    });

    document.getElementById('page-info').innerText = `Page ${page}`;
    document.getElementById('prev').disabled = page === 1;
    document.getElementById('next').disabled = end >= gifs.length;
}

document.getElementById('prev').addEventListener('click', () => {
    if (currentPage > 1) {
        currentPage--;
        showPage(currentPage);
    }
});

document.getElementById('next').addEventListener('click', () => {
    if (currentPage * gifsPerPage < gifs.length) {
        currentPage++;
        showPage(currentPage);
    }
});

showPage(currentPage);